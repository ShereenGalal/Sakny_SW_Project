class ImageConstant {
  static String imgLock20x20 = 'assets/images/img_lock_20x20.svg';

  static String imgVuesaxboldvideocircle =
      'assets/images/img_vuesaxboldvideocircle.svg';

  static String imgImg418x3272 = 'assets/images/img_img_418x327_2.png';

  static String imgCall40x40 = 'assets/images/img_call_40x40.svg';

  static String imgCommentBold24px = 'assets/images/img_comment_bold_24px.svg';

  static String imgMapsiclemap693x3751 =
      'assets/images/img_mapsiclemap_693x375_1.png';

  static String imgPlus1 = 'assets/images/img_plus_1.svg';

  static String imgInstagram = 'assets/images/img_instagram.svg';

  static String imgIcon40x40 = 'assets/images/img_icon_40x40.svg';

  static String imgArrowright20x20 = 'assets/images/img_arrowright_20x20.svg';

  static String imgMenu1 = 'assets/images/img_menu_1.svg';

  static String imgPlus24x24 = 'assets/images/img_plus_24x24.svg';

  static String imgRectangle422462x621 =
      'assets/images/img_rectangle4224_62x62_1.png';

  static String imgEdit12x12 = 'assets/images/img_edit_12x12.svg';

  static String imgArrowleft = 'assets/images/img_arrowleft.svg';

  static String imgIcon24x24 = 'assets/images/img_icon_24x24.svg';

  static String imgWarning = 'assets/images/img_warning.svg';

  static String imgArrowdown = 'assets/images/img_arrowdown.svg';

  static String imgContrast = 'assets/images/img_contrast.svg';

  static String imgCheckmark2 = 'assets/images/img_checkmark_2.svg';

  static String imgFavorite20x20 = 'assets/images/img_favorite_20x20.svg';

  static String imgArrowdownBlueGray50020x20 =
      'assets/images/img_arrowdown_blue_gray_500_20x20.svg';

  static String imgCheckmark20x20 = 'assets/images/img_checkmark_20x20.svg';

  static String imgClose = 'assets/images/img_close.svg';

  static String imgRectangle4259180x2951 =
      'assets/images/img_rectangle4259_180x295_1.png';

  static String imgGroup4348 = 'assets/images/img_group4348.svg';

  static String imgIcon48x48 = 'assets/images/img_icon_48x48.svg';

  static String imgLock = 'assets/images/img_lock.svg';

  static String imgHome1 = 'assets/images/img_home_1.svg';

  static String imgMenu = 'assets/images/img_menu.svg';

  static String imgChartline = 'assets/images/img_chartline.svg';

  static String imgPrinter = 'assets/images/img_printer.svg';

  static String imgCheckmark3 = 'assets/images/img_checkmark_3.svg';

  static String imgRectangle422462x622 =
      'assets/images/img_rectangle4224_62x62_2.png';

  static String imgCheckmark40x40 = 'assets/images/img_checkmark_40x40.svg';

  static String imgSort = 'assets/images/img_sort.svg';

  static String imgCheckmark1 = 'assets/images/img_checkmark_1.svg';

  static String imgMenu16x16 = 'assets/images/img_menu_16x16.svg';

  static String imgClock = 'assets/images/img_clock.svg';

  static String imgImg48x483 = 'assets/images/img_img_48x48_3.png';

  static String imgWarning24x24 = 'assets/images/img_warning_24x24.svg';

  static String imgClose40x40 = 'assets/images/img_close_40x40.svg';

  static String imgArrowright16x16 = 'assets/images/img_arrowright_16x16.svg';

  static String imgDiscount = 'assets/images/img_discount.svg';

  static String imgSettings1 = 'assets/images/img_settings_1.svg';

  static String imgArrowdownGray900 =
      'assets/images/img_arrowdown_gray_900.svg';

  static String imgImg418x3271 = 'assets/images/img_img_418x327_1.png';

  static String imgMapsiclemap152x3271 =
      'assets/images/img_mapsiclemap_152x327_1.png';

  static String imgArrowrightBlueGray501 =
      'assets/images/img_arrowright_blue_gray_50_1.svg';

  static String imgClose14x14 = 'assets/images/img_close_14x14.svg';

  static String img1 = 'assets/images/img_1.png';

  static String imgClock2 = 'assets/images/img_clock_2.svg';

  static String imgImg40x402 = 'assets/images/img_img_40x40_2.png';

  static String imgLocation1 = 'assets/images/img_location_1.svg';

  static String imgArrowright = 'assets/images/img_arrowright.svg';

  static String imgBg48x48 = 'assets/images/img_bg_48x48.png';

  static String imgCheckmark14x14 = 'assets/images/img_checkmark_14x14.svg';

  static String imgUser24x24 = 'assets/images/img_user_24x24.svg';

  static String imgImage83x94 = 'assets/images/img_image_83x94.png';

  static String imgFrame = 'assets/images/img_frame.svg';

  static String imgUser = 'assets/images/img_user.svg';

  static String imgHome20x20 = 'assets/images/img_home_20x20.svg';

  static String imgGlobe = 'assets/images/img_globe.svg';

  static String imgRectangle36170x70 =
      'assets/images/img_rectangle361_70x70.png';

  static String imgImage109x102 = 'assets/images/img_image_109x102.png';

  static String imgArrowrightBlueGray500 =
      'assets/images/img_arrowright_blue_gray_500.svg';

  static String imgOnboarding = 'assets/images/img_onboarding.png';

  static String imgRectangle422462x623 =
      'assets/images/img_rectangle4224_62x62_3.png';

  static String imgImg40x401 = 'assets/images/img_img_40x40_1.png';

  static String imgArrowleftGray900 =
      'assets/images/img_arrowleft_gray_900.svg';

  static String imgMapsiclemap = 'assets/images/img_mapsiclemap.png';

  static String imgLine = 'assets/images/img_line.svg';

  static String imgImg48x484 = 'assets/images/img_img_48x48_4.png';

  static String imgCamera20x20 = 'assets/images/img_camera_20x20.svg';

  static String imgHome2 = 'assets/images/img_home_2.svg';

  static String imgGroup4347 = 'assets/images/img_group4347.png';

  static String imgGroup = 'assets/images/img_group.svg';

  static String imgArrowleft10x10 = 'assets/images/img_arrowleft_10x10.svg';

  static String imgStar16x16 = 'assets/images/img_star_16x16.svg';

  static String imgSettings = 'assets/images/img_settings.svg';

  static String imgArrowdownBlueGray500 =
      'assets/images/img_arrowdown_blue_gray_500.svg';

  static String imgIconGray900 = 'assets/images/img_icon_gray_900.svg';

  static String imgFire = 'assets/images/img_fire.svg';

  static String imgMenuGray900 = 'assets/images/img_menu_gray_900.svg';

  static String imgImg48x482 = 'assets/images/img_img_48x48_2.png';

  static String imgIcon = 'assets/images/img_icon.svg';

  static String imgSignal = 'assets/images/img_signal.svg';

  static String imgImg48x485 = 'assets/images/img_img_48x48_5.png';

  static String imgLocation40x40 = 'assets/images/img_location_40x40.svg';

  static String imgRewind = 'assets/images/img_rewind.svg';

  static String imgFacebook = 'assets/images/img_facebook.png';

  static String imgHomeWhiteA700 = 'assets/images/img_home_white_a700.svg';

  static String imgEye80x80 = 'assets/images/img_eye_80x80.svg';

  static String imgClock1 = 'assets/images/img_clock_1.svg';

  static String imgHome4 = 'assets/images/img_home_4.svg';

  static String imgImg180x3271 = 'assets/images/img_img_180x327_1.png';

  static String imgClockBlue500 = 'assets/images/img_clock_blue_500.svg';

  static String imgMailnotification = 'assets/images/img_mailnotification.svg';

  static String imgUserBlue500 = 'assets/images/img_user_blue_500.svg';

  static String imgNotification = 'assets/images/img_notification.svg';

  static String imgArrowupBlueGray500 =
      'assets/images/img_arrowup_blue_gray_500.svg';

  static String imgPlus = 'assets/images/img_plus.svg';

  static String imgAlarm = 'assets/images/img_alarm.svg';

  static String imgVolume = 'assets/images/img_volume.svg';

  static String imgSearch = 'assets/images/img_search.svg';

  static String imgMail = 'assets/images/img_mail.svg';

  static String imgLocation14x14 = 'assets/images/img_location_14x14.svg';

  static String imgFile = 'assets/images/img_file.svg';

  static String imgArrowdownBlueGray50016x16 =
      'assets/images/img_arrowdown_blue_gray_500_16x16.svg';

  static String home = 'assets/images/home.png';

  static String imgBg1 = 'assets/images/img_bg_1.png';

  static String imgEdit = 'assets/images/img_edit.svg';

  static String imgMenu40x40 = 'assets/images/img_menu_40x40.svg';

  static String imgWhatsapp = 'assets/images/img_whatsapp.svg';

  static String imgCall = 'assets/images/img_call.svg';

  static String imgLocation = 'assets/images/img_location.svg';

  static String imgCamera = 'assets/images/img_camera.svg';

  static String imgHome44x44 = 'assets/images/img_home_44x44.svg';

  static String imgLocation2 = 'assets/images/img_location_2.svg';

  static String imgSearchBlueGray500 =
      'assets/images/img_search_blue_gray_500.svg';

  static String imgFavorite = 'assets/images/img_favorite.svg';

  static String imgStar = 'assets/images/img_star.svg';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imgBg130x100 = 'assets/images/img_bg_130x100.png';

  static String imgGoogle = 'assets/images/img_google.svg';

  static String imgSignal24x24 = 'assets/images/img_signal_24x24.svg';

  static String imgAvatar33x33 = 'assets/images/img_avatar_33x33.png';

  static String imgImg180x3272 = 'assets/images/img_img_180x327_2.png';

  static String imgTicket = 'assets/images/img_ticket.svg';

  static String imgOffer20x20 = 'assets/images/img_offer_20x20.svg';

  static String imgLocation32x32 = 'assets/images/img_location_32x32.svg';

  static String imgImg130x991 = 'assets/images/img_img_130x99_1.png';

  static String imgOffer = 'assets/images/img_offer.svg';

  static String imgLocationBlueGray500 =
      'assets/images/img_location_blue_gray_500.svg';

  static String imgRectangle4259180x2952 =
      'assets/images/img_rectangle4259_180x295_2.png';

  static String imgEye = 'assets/images/img_eye.svg';

  static String imgOptions = 'assets/images/img_options.svg';

  static String imgQuestion = 'assets/images/img_question.svg';

  static String imgImage343x3431 = 'assets/images/img_image_343x343_1.png';

  static String imgHome3 = 'assets/images/img_home_3.svg';

  static String imgLocation20x20 = 'assets/images/img_location_20x20.svg';

  static String imgUser40x40 = 'assets/images/img_user_40x40.svg';

  static String imgCalendar = 'assets/images/img_calendar.svg';

  static String imgSettings40x40 = 'assets/images/img_settings_40x40.svg';

  static String imgLocation24x24 = 'assets/images/img_location_24x24.svg';

  static String imgSliderindicator = 'assets/images/img_sliderindicator.svg';

  static String imgStar1 = 'assets/images/img_star_1.svg';

  static String imgCall20x20 = 'assets/images/img_call_20x20.svg';

  static String imgIcon20x20 = 'assets/images/img_icon_20x20.svg';

  static String imgBg60x60 = 'assets/images/img_bg_60x60.png';

  static String imgHome24x24 = 'assets/images/img_home_24x24.svg';

  static String imgMicrophone = 'assets/images/img_microphone.svg';

  static String imgUserBlueGray500 = 'assets/images/img_user_blue_gray_500.svg';

  static String imgCall1 = 'assets/images/img_call_1.svg';

  static String imgImg40x403 = 'assets/images/img_img_40x40_3.png';

  static String imgImg48x481 = 'assets/images/img_img_48x48_1.png';

  static String imgRectangle361100x100 =
      'assets/images/img_rectangle361_100x100.png';

  static String imgClock24x24 = 'assets/images/img_clock_24x24.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
