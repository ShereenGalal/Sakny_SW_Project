class NavigationArgs {
  static String token = "token";

  static String id = "id";
}
