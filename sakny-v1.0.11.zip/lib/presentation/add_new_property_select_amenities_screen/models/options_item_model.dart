import 'package:get/get.dart';class OptionsItemModel {Rx<String> freewifiTxt = Rx("Free WiFi");

RxBool isSelected = false.obs;

 }
