import 'package:get/get.dart';import 'options_item_model.dart';class AddNewPropertySelectAmenitiesModel {RxList<OptionsItemModel> optionsItemList = RxList.generate(8,(index) =>OptionsItemModel());

 }
