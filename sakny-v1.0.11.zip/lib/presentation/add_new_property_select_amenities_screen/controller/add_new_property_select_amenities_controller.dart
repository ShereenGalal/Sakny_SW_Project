import 'package:sakny/core/app_export.dart';import 'package:sakny/presentation/add_new_property_select_amenities_screen/models/add_new_property_select_amenities_model.dart';class AddNewPropertySelectAmenitiesController extends GetxController {Rx<AddNewPropertySelectAmenitiesModel> addNewPropertySelectAmenitiesModelObj = AddNewPropertySelectAmenitiesModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
