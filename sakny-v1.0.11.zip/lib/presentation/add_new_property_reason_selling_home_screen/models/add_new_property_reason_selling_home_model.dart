class AddNewPropertyReasonSellingHomeModel { }
