import 'package:get/get.dart';import 'questions_item_model.dart';class FaqsGetHelpModel {RxList<QuestionsItemModel> questionsItemList = RxList.generate(4,(index) =>QuestionsItemModel());

 }
