import 'package:get/get.dart';class QuestionsItemModel {Rx<String> howdoesrelaxworOneTxt = Rx("msg_how_does_relax_work".tr);

Rx<String> descriptionTxt = Rx("msg_lorem_ipsum_dol".tr);

RxBool isSelected = false.obs;

 }
