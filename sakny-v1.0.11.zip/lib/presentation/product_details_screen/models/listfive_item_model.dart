import 'package:get/get.dart';class ListfiveItemModel {Rx<String> fiveTxt = Rx("lbl_5".tr);

Rx<String> sixtyTxt = Rx("lbl_60".tr);

String? id = "";

 }
