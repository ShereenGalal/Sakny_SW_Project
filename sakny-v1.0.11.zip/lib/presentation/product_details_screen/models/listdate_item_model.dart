import 'package:get/get.dart';class ListdateItemModel {Rx<String> dateTxt = Rx("lbl_28_12_2021".tr);

Rx<String> listedforsaleTxt = Rx("lbl_listed_for_sale".tr);

Rx<String> priceTxt = Rx("lbl_2_400".tr);

String? id = "";

 }
