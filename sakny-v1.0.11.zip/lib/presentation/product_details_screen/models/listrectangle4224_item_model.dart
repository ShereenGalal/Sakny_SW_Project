import 'package:get/get.dart';class Listrectangle4224ItemModel {Rx<String> thenewschoolatTxt = Rx("msg_the_new_school".tr);

Rx<String> publicprekEightTxt = Rx("msg_public_prek_8".tr);

Rx<String> reviewsCounterTxt = Rx("lbl_12_reviews".tr);

String? id = "";

 }
