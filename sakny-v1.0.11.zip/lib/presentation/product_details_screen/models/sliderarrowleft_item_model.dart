import 'package:get/get.dart';class SliderarrowleftItemModel {String? id = "";

 }
