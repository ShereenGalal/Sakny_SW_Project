class RecentlyViewsModel { }
