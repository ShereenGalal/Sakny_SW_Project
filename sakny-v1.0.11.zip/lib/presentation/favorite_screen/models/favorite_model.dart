class FavoriteModel { }
