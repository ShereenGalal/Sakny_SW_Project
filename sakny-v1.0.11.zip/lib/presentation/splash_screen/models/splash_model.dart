class SplashModel { }
