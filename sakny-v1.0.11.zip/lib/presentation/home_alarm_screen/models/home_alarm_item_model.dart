import 'package:get/get.dart';class HomeAlarmItemModel {String? id = "";

 }
