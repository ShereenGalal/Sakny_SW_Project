import 'package:get/get.dart';class HomeSearchItemModel {Rx<String> mightycincofamiOneTxt = Rx("msg_mighty_cinco_fa".tr);

String? id = "";

 }
