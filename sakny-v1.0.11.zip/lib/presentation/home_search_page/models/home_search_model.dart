import 'package:get/get.dart';import 'home_search_item_model.dart';class HomeSearchModel {RxList<HomeSearchItemModel> homeSearchItemList = RxList.generate(3,(index) => HomeSearchItemModel());

 }
