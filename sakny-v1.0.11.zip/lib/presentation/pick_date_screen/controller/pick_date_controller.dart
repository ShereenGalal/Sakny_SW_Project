import 'package:sakny/core/app_export.dart';import 'package:sakny/presentation/pick_date_screen/models/pick_date_model.dart';class PickDateController extends GetxController {Rx<PickDateModel> pickDateModelObj = PickDateModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
