import 'package:get/get.dart';class Time1ItemModel {Rx<String> timeTxt = Rx("lbl_9_00_am".tr);

String? id = "";

 }
