import 'package:get/get.dart';class Dates1ItemModel {Rx<String> weekdayTxt = Rx("lbl_monday".tr);

Rx<String> dateTxt = Rx("lbl_11".tr);

String? id = "";

 }
