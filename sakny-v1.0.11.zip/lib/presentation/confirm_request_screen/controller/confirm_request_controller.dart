import 'package:sakny/core/app_export.dart';import 'package:sakny/presentation/confirm_request_screen/models/confirm_request_model.dart';class ConfirmRequestController extends GetxController {Rx<ConfirmRequestModel> confirmRequestModelObj = ConfirmRequestModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
