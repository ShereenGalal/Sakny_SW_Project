import 'package:sakny/core/app_export.dart';import 'package:sakny/presentation/select_app_alarm_screen/models/select_app_alarm_model.dart';class SelectAppAlarmController extends GetxController {Rx<SelectAppAlarmModel> selectAppAlarmModelObj = SelectAppAlarmModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
