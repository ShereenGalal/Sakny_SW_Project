import 'package:get/get.dart';class MessageItemModel {Rx<String> wadewarrenTxt = Rx("lbl_wade_warren".tr);

Rx<String> messageTxt = Rx("msg_oh_hello_willam".tr);

Rx<String> timeTxt = Rx("lbl_23_15".tr);

String? id = "";

 }
