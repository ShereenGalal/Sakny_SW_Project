import 'package:sakny/core/app_export.dart';import 'package:sakny/presentation/add_new_property_details_screen/models/add_new_property_details_model.dart';class AddNewPropertyDetailsController extends GetxController {Rx<AddNewPropertyDetailsModel> addNewPropertyDetailsModelObj = AddNewPropertyDetailsModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
