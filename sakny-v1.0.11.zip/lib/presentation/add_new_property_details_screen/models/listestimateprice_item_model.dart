import 'package:get/get.dart';class ListestimatepriceItemModel {Rx<String> estimatepriceTxt = Rx("lbl_estimate_price".tr);

Rx<String> priceTxt = Rx("lbl_4_200_00".tr);

Rx<String> group34508Txt = Rx("lbl_4".tr);

String? id = "";

 }
