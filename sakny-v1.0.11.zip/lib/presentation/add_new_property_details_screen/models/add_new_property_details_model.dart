import 'package:get/get.dart';import 'listestimateprice_item_model.dart';class AddNewPropertyDetailsModel {RxList<ListestimatepriceItemModel> listestimatepriceItemList = RxList.generate(3,(index) => ListestimatepriceItemModel());

 }
