class HomeListingModel { }
