import 'package:get/get.dart';import 'my_home_item_model.dart';class MyHomeModel {RxList<MyHomeItemModel> myHomeItemList = RxList.generate(3,(index) => MyHomeItemModel());

 }
