import 'package:get/get.dart';class MyHomeItemModel {String? id = "";

 }
