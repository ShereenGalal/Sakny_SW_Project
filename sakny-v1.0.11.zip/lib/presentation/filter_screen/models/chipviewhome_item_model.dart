import 'package:get/get.dart';class ChipviewhomeItemModel {Rx<String> homeTxt = Rx("Home");

RxBool isSelected = false.obs;

 }
