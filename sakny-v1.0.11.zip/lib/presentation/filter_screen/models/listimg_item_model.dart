import 'package:get/get.dart';class ListimgItemModel {String? id = "";

 }
