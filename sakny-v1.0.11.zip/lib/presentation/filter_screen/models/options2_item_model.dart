import 'package:get/get.dart';class Options2ItemModel {Rx<String> freewifiTxt = Rx("Free WiFi");

RxBool isSelected = false.obs;

 }
