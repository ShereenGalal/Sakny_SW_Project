import 'package:get/get.dart';class ListbedsItemModel {Rx<String> bedsTxt = Rx("lbl_beds".tr);

Rx<String> fourTxt = Rx("lbl_42".tr);

String? id = "";

 }
