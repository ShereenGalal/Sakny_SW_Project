import 'package:get/get.dart';import 'listwhatsapp_item_model.dart';class SelectVirtualAppModel {RxList<ListwhatsappItemModel> listwhatsappItemList = RxList.generate(3,(index) => ListwhatsappItemModel());

 }
