import 'package:get/get.dart';import 'package:flutter/material.dart';class ListwhatsappItemModel {Rx<String> whatsappOneTxt = Rx("lbl_whatsapp".tr);

TextEditingController streetaddressController = TextEditingController();

String? id = "";

 }
