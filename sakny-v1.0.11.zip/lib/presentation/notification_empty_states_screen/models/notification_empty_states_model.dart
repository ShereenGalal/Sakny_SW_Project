class NotificationEmptyStatesModel { }
