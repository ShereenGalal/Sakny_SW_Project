import 'package:get/get.dart';import 'past_tours_item_model.dart';class PastToursModel {RxList<PastToursItemModel> pastToursItemList = RxList.generate(2,(index) => PastToursItemModel());

 }
