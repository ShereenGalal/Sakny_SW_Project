import 'package:get/get.dart';class PastToursItemModel {Rx<String> canceledTxt = Rx("lbl_canceled".tr);

String? id = "";

 }
