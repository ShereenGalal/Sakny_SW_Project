import 'package:get/get.dart';import 'gridhome_item_model.dart';class ConfirmRequestBottomSheetModel {RxList<GridhomeItemModel> gridhomeItemList = RxList.generate(4,(index) => GridhomeItemModel());

 }
