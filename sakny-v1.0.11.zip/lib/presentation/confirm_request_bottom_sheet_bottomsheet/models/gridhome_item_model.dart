import 'package:get/get.dart';class GridhomeItemModel {Rx<String> homeclosedTxt = Rx("lbl_home_closed".tr);

Rx<String> twentyFiveTxt = Rx("lbl_25".tr);

String? id = "";

 }
