import 'package:sakny/core/app_export.dart';import 'package:sakny/presentation/confirm_request_bottom_sheet_bottomsheet/models/confirm_request_bottom_sheet_model.dart';class ConfirmRequestBottomSheetController extends GetxController {Rx<ConfirmRequestBottomSheetModel> confirmRequestBottomSheetModelObj = ConfirmRequestBottomSheetModel().obs;

@override void onReady() { super.onReady(); } 
@override void onClose() { super.onClose(); } 
 }
