import 'package:get/get.dart';class ListhomeItemModel {Rx<String> therearegooddeaOneTxt = Rx("msg_there_are_good".tr);

Rx<String> distanceTxt = Rx("lbl_1m_ago".tr);

String? id = "";

 }
