import 'package:get/get.dart';class ListchartlineItemModel {Rx<String> thehousewiththeOneTxt = Rx("msg_the_house_with".tr);

Rx<String> thereareseveralOneTxt = Rx("msg_there_are_sever".tr);

Rx<String> durationTxt = Rx("lbl_4_days".tr);

String? id = "";

 }
