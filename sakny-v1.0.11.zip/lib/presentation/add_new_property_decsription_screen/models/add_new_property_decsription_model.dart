class AddNewPropertyDecsriptionModel { }
