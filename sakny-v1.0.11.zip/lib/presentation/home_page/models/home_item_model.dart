import 'package:get/get.dart';class HomeItemModel {String? id = "";

 }
