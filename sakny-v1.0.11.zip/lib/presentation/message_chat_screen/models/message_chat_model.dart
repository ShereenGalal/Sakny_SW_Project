class MessageChatModel { }
