class AddNewPropertyContactModel { }
