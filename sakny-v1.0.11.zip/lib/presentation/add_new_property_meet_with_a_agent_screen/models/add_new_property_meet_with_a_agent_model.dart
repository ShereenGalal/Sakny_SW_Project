import 'package:get/get.dart';import 'dates_item_model.dart';import 'time_item_model.dart';class AddNewPropertyMeetWithAAgentModel {RxList<DatesItemModel> datesItemList = RxList.generate(4,(index) => DatesItemModel());

RxList<TimeItemModel> timeItemList = RxList.generate(4,(index) => TimeItemModel());

 }
