import 'package:get/get.dart';class DatesItemModel {Rx<String> weekdayTxt = Rx("lbl_monday".tr);

Rx<String> elevenTxt = Rx("lbl_11".tr);

String? id = "";

 }
