class AddNewPropertyTimeToSellModel { }
