import 'package:sakny/core/app_export.dart';

class ApiClient extends GetConnect {}
